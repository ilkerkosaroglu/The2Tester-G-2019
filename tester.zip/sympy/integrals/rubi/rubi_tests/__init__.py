'''
rubi_tests contain test cases parsed in sympy format.
The complete test suite is here: http://www.apmaths.uwo.ca/~arich/IntegrationProblems/MathematicaSyntaxFiles/MathematicaSyntaxFiles.html

The current version of test suite is 4.10.8

TODO
====
* Update test suite to latest version
'''
